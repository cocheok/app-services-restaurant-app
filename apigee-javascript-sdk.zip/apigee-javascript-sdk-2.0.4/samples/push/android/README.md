##Apigee Push Notifications for Android using PhoneGap

Here is an example implmentation of Apigee Push Notifications using our Cordova/PhoneGap plugin. Edit the assets/www/js/index.js file with all of your information. This app assumes that you have created a notifier already named `"android_push"` in your app.


